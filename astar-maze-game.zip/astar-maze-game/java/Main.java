import java.util.*;

public class Main {

    static String[] maze = {
        "............",
        "............",
        "............",
        "S....#.....G",
        ".....#......",
        ".....#......",
        "............",
        "............"
    };

    static int rows = maze.length;
    static int cols = maze[0].length();
    static int goalRow, goalCol;
    static boolean useHeuristic;
    static int expanded;

    static class Node {
        int row, col, g, f;
        Node parent;

        Node(int row, int col, int g, int f, Node parent) {
            this.row = row;
            this.col = col;
            this.g = g;
            this.f = f;
            this.parent = parent;
        }
    }

    static int heuristic(int row, int col) {
        if (!useHeuristic) return 0;
        return Math.abs(row - goalRow) + Math.abs(col - goalCol);
    }

    static Node aStar(int startRow, int startCol) {
        expanded = 0;
        PriorityQueue<Node> open = new PriorityQueue<>((a, b) -> a.f - b.f);
        boolean[][] closed = new boolean[rows][cols];
        int[] dr = {-1, 1, 0, 0};
        int[] dc = {0, 0, -1, 1};

        open.add(new Node(startRow, startCol, 0, heuristic(startRow, startCol), null));

        while (!open.isEmpty()) {
            Node current = open.poll();

            if (closed[current.row][current.col]) continue;
            closed[current.row][current.col] = true;
            expanded++;

            if (current.row == goalRow && current.col == goalCol) return current;

            for (int k = 0; k < 4; k++) {
                int nr = current.row + dr[k];
                int nc = current.col + dc[k];

                if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;
                if (maze[nr].charAt(nc) == '#') continue;
                if (closed[nr][nc]) continue;

                int g = current.g + 1;
                int f = g + heuristic(nr, nc);
                open.add(new Node(nr, nc, g, f, current));
            }
        }
        return null;
    }

    static void printPath(Node goal) {
        char[][] grid = new char[rows][cols];
        for (int r = 0; r < rows; r++) {
            grid[r] = maze[r].toCharArray();
        }
        for (Node n = goal.parent; n != null && n.parent != null; n = n.parent) {
            grid[n.row][n.col] = '*';
        }
        for (char[] line : grid) {
            System.out.println(new String(line));
        }
    }

    public static void main(String[] args) {
        int startRow = 0, startCol = 0;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (maze[r].charAt(c) == 'S') {
                    startRow = r;
                    startCol = c;
                }
                if (maze[r].charAt(c) == 'G') {
                    goalRow = r;
                    goalCol = c;
                }
            }
        }

        useHeuristic = true;
        Node result = aStar(startRow, startCol);
        System.out.println("A* search (f = g + h)");
        printPath(result);
        System.out.println("Path cost: " + result.g);
        System.out.println("Cells expanded: " + expanded);

        int withH = expanded;

        useHeuristic = false;
        Node blind = aStar(startRow, startCol);
        System.out.println();
        System.out.println("Same search without heuristic (h = 0)");
        System.out.println("Path cost: " + blind.g);
        System.out.println("Cells expanded: " + expanded);

        System.out.println();
        System.out.println("Heuristic saved " + (expanded - withH) + " expansions");
    }
}
