# A* Maze

A small browser game for the AISC (CSE3121) heuristic search project. You build walls on a grid, and the A* algorithm finds the cheapest path from the start (S) to the goal (G) every time you change the maze.

## What you can do

- Click or drag on the grid to place or remove walls.
- Drag the green S or the red G to move them.
- See the cheapest path, shown as amber coins, and the cells A* searched, shown in blue.
- Compare A* with the same search without a heuristic. The panel shows how many cells each one searched.
- Press Replay search to watch the search spread out and the route appear.
- Press Random walls to generate a maze that always has a path.

## Files

| File | Purpose |
|---|---|
| `index.html` | Page structure |
| `style.css` | Look and layout |
| `astar.js` | The A* algorithm (the engine) |
| `game.js` | The grid, mouse, touch and keyboard controls |
| `java/Main.java` | The original Java version used for the project submission |

`astar.js` is a line-by-line port of `java/Main.java`: same open list ordering, same neighbour order (up, down, left, right), same Manhattan heuristic. On the sample maze both give a path cost of 13, with 28 cells searched by A* and 83 without the heuristic.

## Why there is no server

GitHub Pages hosts static files only, so the algorithm runs in the visitor's browser. That is fast enough for a grid this size, and it means there is nothing to install or keep running.

## Run it on your computer

Open `index.html` in any browser. No build step is needed.

## Put it on GitHub Pages

1. On github.com, click **New repository**. Name it `astar-maze` and make it **Public**.
2. Click **uploading an existing file**, then drag in everything from this folder, including the `java` folder. Click **Commit changes**.
3. Open **Settings**, then **Pages**. Under **Build and deployment**, set **Source** to **Deploy from a branch**. Choose branch **main** and folder **/ (root)**, then click **Save**.
4. Wait about a minute. The page shows your link, which looks like `https://YOUR-USERNAME.github.io/astar-maze/`.

## How A* works here

Each cell gets a score `f = g + h`.

- `g` is the number of steps taken from the start.
- `h` is the Manhattan distance to the goal: |row difference| + |column difference|.
- A* always expands the open cell with the lowest `f`.

Manhattan distance never overestimates when moving up, down, left or right, so the path A* returns is always the cheapest one.
